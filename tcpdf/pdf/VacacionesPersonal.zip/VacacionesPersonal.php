<?php

require_once "../../controlador/gestorVacaciones.php";
require_once "../../modelo/gestorVacaciones.php";

class ImpresionVacaciones{

public function imprimirVacaciones(){

require_once('tcpdf_include.php');

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->AddPage();

$html1 = <<<EOF
	
	<table>
		<tr>
			<td style="width:540px"><img src="images/back.jpg"></td>
		</tr>

		<tr>
			<td style="width:540px"><img src="images/sin.png"></td>
		</tr>
	</table>

	<table style="border: 1px solid #333; text-align:center; line-height: 20px; font-size:10px">
		<tr>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Cédula</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Nombre</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Fecha de antiguedad</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Fecha de inicio</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Fecha de finalización</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Tipo de vacaciones</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Periodo</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Quinquenio</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Días a disfrutar</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Total de días del periodo</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Días disfrutados</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Días por disfrutar</td>
			<td width="41.48px" style="border: 1px solid #666; background-color:#333; color:#fff">Días pendientes por disfrutar</td>
			
		</tr>
	</table>

EOF;

$pdf->writeHTML($html1, false, false, false, false, ''); 

$respuesta = GestorVacaciones::impresionVacacionesPersonalController("vacaciones");

foreach ($respuesta as $row => $item) {
$vacacionesfechaini = new DateTime($item["fecha_ini"]);
$vacacionesfechaini=$vacacionesfechaini->format("d/m/Y");

$vacacionesfechafin= new DateTime($item["fecha_fin"]);
$vacacionesfechafin=$vacacionesfechafin->format("d/m/Y");

$nombrecompleto = $item["nombre"] .' '. $item["apellido"];

$html2 = <<<EOF

	<table style="border: 1px solid #333; text-align:center; line-height: 20px; font-size:10px">
		<tr>
			<td style="border: 1px solid #666;">$item[cedula_personal]</td>
			<td style="border: 1px solid #666;">$nombrecompleto</td>
			<td style="border: 1px solid #666;">$item[a_antiguedad]</td>
			<td style="border: 1px solid #666;">$vacacionesfechaini</td>
			<td style="border: 1px solid #666;">$vacacionesfechafin</td>
			<td style="border: 1px solid #666;">$item[nombre_tipovac]</td>
			<td style="border: 1px solid #666;">$item[periodo]</td>
			<td style="border: 1px solid #666;">$item[quinquenio]</td>
			<td style="border: 1px solid #666;">$item[dias_disfrutar]</td>
			<td style="border: 1px solid #666;">$item[total_periodo]</td>
			<td style="border: 1px solid #666;">$item[dias_disfrutados]</td>
			<td style="border: 1px solid #666;">$item[por_disfrutar]</td>
			<td style="border: 1px solid #666;">$item[pendientes_disfrutar]</td>
			
		</tr>
	</table>

EOF;

$pdf->writeHTML($html2, false, false, false, false, ''); 	

}

$pdf->Output('Vacaciones.pdf');

}

}

$a = new ImpresionVacaciones();
$a -> imprimirVacaciones();

?>