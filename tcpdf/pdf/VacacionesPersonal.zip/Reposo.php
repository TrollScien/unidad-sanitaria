<?php

require_once "../../controlador/gestorReposos.php";
require_once "../../modelo/gestorReposos.php";

class ImpresionReposos{

public function imprimirReposos(){

require_once('tcpdf_include.php');

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->AddPage();

$html1 = <<<EOF
	
	<table>
		<tr>
			<td style="width:540px"><img src="images/back.jpg"></td>
		</tr>

		<tr>
			<td style="width:540px"><img src="images/sin.png"></td>
		</tr>
	</table>

	<table style="border: 1px solid #333; text-align:center; line-height: 20px; font-size:10px">
		<tr>
			<td width="77px" style="border: 1px solid #666; background-color:#333; color:#fff">Cédula</td>
			<td width="77px" style="border: 1px solid #666; background-color:#333; color:#fff">Nombre</td>
			<td width="77px" style="border: 1px solid #666; background-color:#333; color:#fff">Médico</td>
			<td width="77px" style="border: 1px solid #666; background-color:#333; color:#fff">Patologías</td>
			<td width="77px" style="border: 1px solid #666; background-color:#333; color:#fff">Fecha de inicio</td>
			<td width="77px" style="border: 1px solid #666; background-color:#333; color:#fff">Fecha de finalización</td>
			<td width="77px" style="border: 1px solid #666; background-color:#333; color:#fff">Observaciones</td>
			
		</tr>
	</table>

EOF;

$pdf->writeHTML($html1, false, false, false, false, ''); 

$respuesta = RepososController::impresionRepososController("reposo");

foreach ($respuesta as $row => $item) {
$reposofechaini = new DateTime($item["fecha_inicio"]);
$reposofechaini=$reposofechaini->format("d/m/Y");

$reposofechafin= new DateTime($item["fecha_fin"]);
$reposofechafin=$reposofechafin->format("d/m/Y");

$nombrecompleto = $item["nombre"] .' '. $item["apellido"];

$html2 = <<<EOF

	<table style="border: 1px solid #333; text-align:center; line-height: 20px; font-size:10px">
		<tr>
			<td style="border: 1px solid #666;">$item[cedula_perso]</td>
			<td style="border: 1px solid #666;">$nombrecompleto</td>
			<td style="border: 1px solid #666;">$item[medico]</td>
			<td style="border: 1px solid #666;">$item[nombre_patologia]</td>
			<td style="border: 1px solid #666;">$reposofechaini</td>
			<td style="border: 1px solid #666;">$reposofechafin</td>
			<td style="border: 1px solid #666;">$item[observaciones]</td>
			
		</tr>
	</table>

EOF;

$pdf->writeHTML($html2, false, false, false, false, ''); 	

}

$pdf->Output('Reposos.pdf');

}

}

$a = new ImpresionReposos();
$a -> imprimirReposos();

?>