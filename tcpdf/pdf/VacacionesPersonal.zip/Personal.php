<?php

require_once "../../controlador/GestorPersonal.php";
require_once "../../modelo/GestorPersonal.php";

class ImpresionPersonal{

public function imprimirPersonal(){

require_once('tcpdf_include.php');

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->AddPage();

$html1 = <<<EOF
	
	<table>
		<tr>
			<td style="width:540px"><img src="images/back.jpg"></td>
		</tr>

		<tr>
			<td style="width:540px"><img src="images/sin.png"></td>
		</tr>
	</table>

	<table style="border: 1px solid #333; text-align:center; line-height: 20px; font-size:10px">
		<tr>
			<td width="60px" style="border: 1px solid #666; background-color:#333; color:#fff">Cédula</td>
			<td width="60px" style="border: 1px solid #666; background-color:#333; color:#fff">Nombre</td>
			<td width="60px" style="border: 1px solid #666; background-color:#333; color:#fff">Fecha de nacimiento</td>
			<td width="60px" style="border: 1px solid #666; background-color:#333; color:#fff">Fecha de ingreso</td>
			<td width="60px" style="border: 1px solid #666; background-color:#333; color:#fff">Sexo</td>
			<td width="60px" style="border: 1px solid #666; background-color:#333; color:#fff">Tipo de personal</td>
			<td width="60px" style="border: 1px solid #666; background-color:#333; color:#fff">Cargo</td>
			<td width="60px" style="border: 1px solid #666; background-color:#333; color:#fff">Ubicación</td>
			<td width="59px" style="border: 1px solid #666; background-color:#333; color:#fff">Condición</td>
			
		</tr>
	</table>

EOF;

$pdf->writeHTML($html1, false, false, false, false, ''); 

$respuesta = PersonalController::impresionPersonalController("personal");

foreach ($respuesta as $row => $item) {
$articulofechanacim = new DateTime($item["fecha_nacimiento"]);
$articulofechanacim=$articulofechanacim->format("d/m/Y");

$articulofechaingre= new DateTime($item["fecha_ingreso"]);
$articulofechaingre=$articulofechaingre->format("d/m/Y");

$nombrecompleto = $item["nombre"] .' '. $item["apellido"];

$condicion = $item["nombre_tipocon"] . ' '. $item["nombre_condicion"];

$html2 = <<<EOF

	<table style="border: 1px solid #333; text-align:center; line-height: 20px; font-size:10px">
		<tr>
			<td style="border: 1px solid #666;">$item[cedula_personal]</td>
			<td style="border: 1px solid #666;">$nombrecompleto</td>
			<td style="border: 1px solid #666;">$articulofechanacim</td>
			<td style="border: 1px solid #666;">$articulofechaingre</td>
			<td style="border: 1px solid #666;">$item[sexo]</td>
			<td style="border: 1px solid #666;">$item[nombre_tipoper]</td>
			<td style="border: 1px solid #666;">$item[nombre_cargo]</td>
			<td style="border: 1px solid #666;">$item[nombre_lugar]</td>
			<td style="border: 1px solid #666;">$condicion</td>
			
			
		</tr>
	</table>

EOF;

$pdf->writeHTML($html2, false, false, false, false, ''); 	

}

$pdf->Output('Personal.pdf');

}

}

$a = new ImpresionPersonal();
$a -> imprimirPersonal();

?>